import javax.swing.*;
import java.awt.*;

public class WelcomePage extends JFrame {
    public WelcomePage() {
        setTitle("Welcome to Our App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        JLabel welcomeLabel = new JLabel("Welcome to Symptom Checker");
        welcomeLabel.setFont(new Font("Helvetica", Font.BOLD, 36));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JButton registerButton = new JButton("   User   ");
        registerButton.setFont(new Font("Helvetica", Font.PLAIN, 18));
        registerButton.setBackground(new Color(59, 89, 182));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JButton adminButton = new JButton("  Admin  ");
        adminButton.setFont(new Font("Helvetica", Font.PLAIN, 18));
        adminButton.setBackground(new Color(59, 89, 182));
        adminButton.setForeground(Color.WHITE);
        adminButton.setFocusPainted(false);
        adminButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        registerButton.addActionListener(e -> {
            new RegisterPage();
        });

        adminButton.addActionListener(e -> {
            new AdminLoginPage();
            dispose();
        });

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBackground(new Color(44, 62, 80));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        contentPanel.add(welcomeLabel, BorderLayout.NORTH);

        JPanel registrationPanel = new JPanel();
        registrationPanel.setLayout(new BoxLayout(registrationPanel, BoxLayout.Y_AXIS));
        registrationPanel.setBackground(new Color(44, 62, 80));
        registrationPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JLabel registerMessageLabel = new JLabel("Please register by clicking on this button");
        registerMessageLabel.setFont(new Font("Helvetica", Font.PLAIN, 20));
        registerMessageLabel.setForeground(Color.WHITE);
        registerMessageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        registerMessageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerMessageLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        registrationPanel.add(registerMessageLabel);
        registrationPanel.add(registerButton);
        registrationPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        registrationPanel.add(adminButton);

        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        adminButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        contentPanel.add(registrationPanel, BorderLayout.CENTER);

        setContentPane(contentPanel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new WelcomePage());
    }
}

import javax.swing.*;
import java.awt.*;

public class AdminCheckPage extends JFrame {
    public AdminCheckPage() {
        setTitle("Admin Check");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        JLabel titleLabel = new JLabel("Admin Check");
        titleLabel.setFont(new Font("Helvetica", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JButton addDiseaseButton = new JButton("Add Disease");
        addDiseaseButton.setFont(new Font("Helvetica", Font.PLAIN, 16));
        addDiseaseButton.setBackground(new Color(59, 89, 182));
        addDiseaseButton.setForeground(Color.WHITE);
        addDiseaseButton.setFocusPainted(false);
        addDiseaseButton.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JButton checkRegistrationsButton = new JButton("Check Registrations");
        checkRegistrationsButton.setFont(new Font("Helvetica", Font.PLAIN, 16));
        checkRegistrationsButton.setBackground(new Color(59, 89, 182));
        checkRegistrationsButton.setForeground(Color.WHITE);
        checkRegistrationsButton.setFocusPainted(false);
        checkRegistrationsButton.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JButton predictedDiseaseButton = new JButton("Predicted Disease Frequency");
        predictedDiseaseButton.setFont(new Font("Helvetica", Font.PLAIN, 16));
        predictedDiseaseButton.setBackground(new Color(59, 89, 182));
        predictedDiseaseButton.setForeground(Color.WHITE);
        predictedDiseaseButton.setFocusPainted(false);
        predictedDiseaseButton.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));


        addDiseaseButton.addActionListener(e -> {
            new AdmininputPage();
            dispose();
        });

        checkRegistrationsButton.addActionListener(e -> {
            new TotalRegistrationsPage();
            dispose();
        });
        predictedDiseaseButton.addActionListener(e -> {
            new PredictedDiseaseWordFrequency();
            dispose();
        });
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Helvetica", Font.PLAIN, 14));
        backButton.setBackground(new Color(59, 89, 182));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        backButton.addActionListener(e -> {
            dispose();
            new WelcomePage();
        });

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBackground(new Color(44, 62, 80));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        contentPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 0, 10));
        buttonPanel.setBackground(new Color(44, 62, 80));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        buttonPanel.add(addDiseaseButton);
        buttonPanel.add(checkRegistrationsButton);
        buttonPanel.add(predictedDiseaseButton);

        JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        backButtonPanel.setBackground(new Color(44, 62, 80));
        backButtonPanel.add(backButton);

        contentPanel.add(buttonPanel, BorderLayout.CENTER);
        contentPanel.add(backButtonPanel, BorderLayout.SOUTH);

        setContentPane(contentPanel);
        setVisible(true);
    }
}

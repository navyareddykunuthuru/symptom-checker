import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.*;

public class EnterSymptoms extends JFrame {

    public EnterSymptoms() {
        setTitle("Select Symptoms");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        JLabel headingLabel = new JLabel("Select Symptoms");
        headingLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headingLabel.setOpaque(true);
        headingLabel.setBackground(new Color(44, 62, 80));
        headingLabel.setForeground(Color.WHITE);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridLayout(7, 2, 10, 10));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.setBackground(Color.WHITE);

        String[] symptoms = {"Symptom 1", "Symptom 2", "Symptom 3", "Symptom 4", "Symptom 5", "Symptom 6"};

        for (int i = 0; i < symptoms.length; i++) {
            JLabel label = new JLabel(symptoms[i] + ":");
            FilteredComboBox diseaseComboBox;
            if (i >= symptoms.length - 3) {
                String[] diseases = getSymptomsWithNone();
                diseaseComboBox = new FilteredComboBox(diseases, "Select");
            } else {
                String[] diseases = getSymptoms();
                diseaseComboBox = new FilteredComboBox(diseases, "Select");
            }
            diseaseComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
            contentPanel.add(label);
            contentPanel.add(diseaseComboBox);
        }

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(44, 62, 80));

        JButton checkButton = new JButton("Check");
        checkButton.setForeground(Color.BLACK);

        buttonPanel.add(checkButton);

        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedSymptomsCount = 0;
                String[] selectedSymptomsArray = new String[symptoms.length];
                for (int i = 0; i < symptoms.length; i++) {
                    FilteredComboBox comboBox = (FilteredComboBox) contentPanel.getComponent(i * 2 + 1);
                    String selectedSymptom = (String) comboBox.getSelectedItem();
                    if (selectedSymptom != null && !selectedSymptom.isEmpty() && !selectedSymptom.equals("Select") && !selectedSymptom.equals("None")) {
                        selectedSymptomsArray[selectedSymptomsCount++] = selectedSymptom;
                    }
                }
                if (selectedSymptomsCount < 1) {
                    JOptionPane.showMessageDialog(EnterSymptoms.this, "Please select at least one symptoms.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    selectedSymptomsArray = Arrays.copyOf(selectedSymptomsArray, selectedSymptomsCount);
                    JOptionPane.showMessageDialog(EnterSymptoms.this, "Selected Symptoms:\n" + Arrays.toString(selectedSymptomsArray), "Selected Symptoms", JOptionPane.INFORMATION_MESSAGE);
                    new DiseaseOutputPage(selectedSymptomsArray);
                }
            }
        });

        add(headingLabel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);

    }

    private String[] getSymptoms() {
        return new String[]{"Abdominal Cramps", "Abdominal Pain", "Abnormal Pap Test Results", "Abnormal Vaginal Bleeding",
                "Aerophobia", "Anxiety that Interferes with Daily Life", "Bladder Habits", "Bloating",
                "Blood in the Sputum", "Blood in the Stool", "Blood in the Urine", "Bloody Stool",
                "Blurred Vision", "Bulge in the Wall of the Aorta", "Burning", "Can Make It Difficult to Breathe",
                "Change in Bowel Habits", "Changes in Appetite", "Changes in Bowel", "Changes in Personality or Behavior",
                "Changes in Urination", "Chest Pain", "Chest Tightness", "Chills", "Chronic Autoimmune Disease that Can Affect Any Part of the Body",
                "Chronic Bronchitis", "Condition in which the Heart Cannot Pump Blood as Well as It Should", "Condition that Affects the Lungs",
                "Confusion", "Congestion", "Conjunctivitis", "Constipation", "Cough", "Cough that Does Not Go Away",
                "Cuts that are Slow to Heal", "Damage to the Kidneys that Can Lead to Kidney Failure", "Decreased Kidney Function",
                "Diarrhea", "Difficulty Breathing", "Difficulty Getting", "Difficulty Speaking", "Difficulty Swallowing",
                "Difficulty Thinking", "Difficulty Urinating", "Difficulty with Balance", "Difficulty with Social Interaction",
                "Discharge from the Penis or Vagina", "Discharge from the Vagina or Penis", "Disturbance in Eating Behavior that Can Lead to Serious Health Problems",
                "Dizziness", "Elevated Body Temperature", "Emphysema", "Energy Levels", "Erectile Dysfunction",
                "Excessive Worry", "Extreme Mood Swings", "Fainting", "Fatigue","Fear", "Fever", "Frequent Urination",
                "From Manito Depression", "Headache", "Heart Disease", "High Blood Pressure", "High Levels of Cholesterol in the Blood",
                "Hoarseness", "Hopelessness", "Hydrophobia", "Hyperthyroidism", "Hypothyroidism", "Impaired Judgment",
                "Increased Pressure in the Eye that Can Damage the Optic Nerve", "Increased Thirst", "Indigestion",
                "Inflamed Skin", "Inflammation in Bursa", "Inflammation in the Eye", "Inflammation in the Joints",
                "Inflammation of the Liver", "Itching", "Itchy Eyes", "Itchy Nose", "Jaundice", "Keeping an Erection",
                "Lead to Vision Loss", "Lightheadedness", "Liver Damage", "Loose", "Loss of Interest in Activities",
                "Lump in the Neck", "Memory Loss", "Memory Problems", "Mucus Production", "Muscle Aches", "Narrowing of the Stool",
                "Nausea", "Night Sweats", "Numbness", "Numbness on One Side of the Body", "Other Parts of the Body",
                "Pain During Sex", "Pain in the Back or Hips", "Pain in the Lower Abdomen", "Pain in the Lower Back or Side",
                "Pain in the Lower Right Abdomen", "Pain in the Upper Abdomen", "Pain in the Upper Right Abdomen",
                "Pain or Burning when Urinating", "Painful Rash that Follows Nerve Path", "Painful Urination", "Pale Skin",
                "Persistent Cough", "Physical Dependence on Alcohol", "Pink Eye", "Rash", "Red Eyes", "Redness",
                "Repetitive Behaviors", "Restricted Interests", "Rough Growths on the Skin", "Runny Nose", "Runny or Stuffy Nose",
                "Sadness", "Seizures", "Sensitivity to Cold", "Sensitivity to Light", "Severe Headache",
                "Sexually Transmitted Infection that Can Cause Blisters on the Genitals",
                "Sexually Transmitted Infection that Can Cause Burning During Urination", "Shortness of Breath", "Sleep",
                "Slow Movement", "Sneezing", "Sore Throat", "Stiff Neck", "Stiffness", "Stiffness in the Joints",
                "Such as Diarrhea", "Sudden Weakness", "Sweating", "Swelling", "Swollen", "Swollen Lymph Nodes", "Symptoms",
                "Tenderness", "Tenderness in the Affected Area", "The Largest Artery in the Body", "Throat", "Tingling at the Bite Site",
                "Tingling in the Arms or Legs", "Tolerance to Alcohol", "Tremors", "Trouble Seeing in One Eye",
                "Twisted Veins", "Unexplained Bleeding or Discharge", "Unexplained Heat Intolerance", "Unexplained Weight Loss",
                "Urgency to Urinate", "Usually in the Legs", "Vomiting", "Warmth", "Watery Eyes", "Watery Stools", "Weight Loss",
                "Wheezing", "Which is an Overactive Thyroid", "Which is an Underactive Thyroid", "Which is Small Sac of Fluid that Cushions Joints"};
    }


    private String[] getSymptomsWithNone() {
        String[] diseases = getSymptoms();
        String[] diseasesWithNone = Arrays.copyOf(diseases, diseases.length + 1);
        diseasesWithNone[diseases.length] = "None";
        return diseasesWithNone;
    }
}

class FilteredComboBox extends JComboBox<String> {
    private final String[] items;
    private final LinkedList<String> filteredItems;

    public FilteredComboBox(String[] items, String placeholder) {
        super(items);
        this.items = items;
        this.filteredItems = new LinkedList<>();
        filteredItems.add(placeholder);
        filteredItems.addAll(Arrays.asList(items));
        setEditable(true);
        JTextField textField = (JTextField) this.getEditor().getEditorComponent();
        textField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                SwingUtilities.invokeLater(() -> {
                    String text = textField.getText();
                    setFilter(text);
                });
            }
        });
        setSelectedItem(placeholder);
    }

    public void setFilter(String text) {
        filteredItems.clear();
        filteredItems.add("");
        for (String item : items) {
            if (item.toLowerCase().contains(text.toLowerCase())) {
                filteredItems.add(item);
            }
        }
        removeAllItems();
        for (String item : filteredItems) {
            addItem(item);
        }
        setSelectedItem(text);

    }

}
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

public class PredictedDiseaseWordFrequency extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;
    private int maxFrequency = 0;

    public PredictedDiseaseWordFrequency() {
        setTitle("Predicted Disease Word Frequency");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(600, 400));

        JPanel mainPanel = new JPanel(new BorderLayout());

        tableModel = new DefaultTableModel(new Object[]{"Disease name", "Count"}, 0);
        table = new JTable(tableModel);
        table.setFont(new Font("Arial", Font.PLAIN, 16));
        table.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> System.exit(0));

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            dispose(); // Close current window
            new AdminCheckPage(); // Open AdminCheckPage
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(backButton);
        buttonPanel.add(closeButton);

        getContentPane().setBackground(new Color(44, 62, 80));
        mainPanel.setBackground(new Color(44, 62, 80));
        buttonPanel.setBackground(new Color(44, 62, 80));

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
        pack();
        setLocationRelativeTo(null);

        displayWordFrequencies();
        setVisible(true);

    }

    private void displayWordFrequencies() {
        Map<String, Integer> wordFreq = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader("user_information.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String predictedDiseases = line.substring(line.indexOf("Predicted Diseases:") + "Predicted Diseases:".length()).trim();
                String[] diseases = predictedDiseases.split(",\\s*");
                for (String disease : diseases) {
                    disease = disease.toUpperCase();
                    int count = wordFreq.getOrDefault(disease, 0) + 1;
                    wordFreq.put(disease, count);
                    if (count >= maxFrequency) {
                        if (count > maxFrequency) {
                            maxFrequency = count; // Update maxFrequency
                        }
                    }
                }
            }

            tableModel.setRowCount(0);

            wordFreq.entrySet().stream()
                    .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                    .forEachOrdered(entry -> {
                        tableModel.addRow(new Object[]{entry.getKey(), entry.getValue()});
                    });

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class CustomTableCellRenderer extends DefaultTableCellRenderer {
        private final List<Integer> rowIndicesToHighlight;

        public CustomTableCellRenderer(List<Integer> rowIndicesToHighlight) {
            this.rowIndicesToHighlight = rowIndicesToHighlight;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            Component cellComponent = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (rowIndicesToHighlight.contains(row)) {
                cellComponent.setBackground(Color.YELLOW);
            } else {
                cellComponent.setBackground(Color.WHITE);
            }
            return cellComponent;
        }
    }


}

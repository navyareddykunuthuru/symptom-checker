import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

class DiseaseOutputPage extends JFrame {
    private DiseaseData diseaseData;

    public DiseaseOutputPage(String[] selectedSymptomsArray) {
        UserData userData = UserData.getInstance();
        String username = userData.getUsername();
        String email = userData.getEmail();
        String age = userData.getAge();
        String phone = userData.getPhone();
        String gender = userData.getGender();
        setTitle("Disease Output Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        diseaseData = new DiseaseData();

        List<String> possibleDiseases = diseaseData.getDiseasesBySymptoms(selectedSymptomsArray);

        writeUserInfoAndDiseasesToFile(username, email, age, phone, gender, possibleDiseases, selectedSymptomsArray);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(new Color(44, 62, 80));

        if (possibleDiseases.isEmpty()) {
            JLabel noDiseaseLabel = new JLabel("No diseases found for the selected symptoms.");
            noDiseaseLabel.setForeground(Color.WHITE);
            noDiseaseLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
            noDiseaseLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(noDiseaseLabel);
        } else {
            for (String diseaseName : possibleDiseases) {
                Disease disease = diseaseData.getDiseaseByName(diseaseName);

                JPanel diseasePanel = new JPanel();
                diseasePanel.setLayout(new BoxLayout(diseasePanel, BoxLayout.Y_AXIS));
                diseasePanel.setBackground(new Color(52, 73, 94));
                diseasePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
                diseasePanel.setMaximumSize(new Dimension(550, 200));

                JLabel diseaseNameLabel = new JLabel("<html><b>Disease Name: </b>" + diseaseName.toUpperCase() + "</html>");
                diseaseNameLabel.setForeground(Color.WHITE);
                diseaseNameLabel.setFont(new Font("SansSerif", Font.BOLD, 18));

                JLabel symptomsLabel = new JLabel("<html><b>Symptoms: </b>" + String.join(", ", disease.getSymptoms()) + "</html>");
                symptomsLabel.setForeground(Color.WHITE);
                symptomsLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));

                JLabel curesLabel = new JLabel("<html><b>Cures: </b>" + String.join(", ", disease.getCures()) + "</html>");
                curesLabel.setForeground(Color.WHITE);
                curesLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));

                JLabel doctorsLabel = new JLabel("<html><b>Doctors: </b>" + String.join(", ", disease.getDoctors()) + "</html>");
                doctorsLabel.setForeground(Color.WHITE);
                doctorsLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));

                JLabel riskLevelLabel = new JLabel("<html><b>Risk Level: </b>" + disease.getRiskLevel() + "</html>");
                riskLevelLabel.setForeground(Color.WHITE);
                riskLevelLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));

                diseasePanel.add(diseaseNameLabel);
                diseasePanel.add(Box.createRigidArea(new Dimension(0, 5)));
                diseasePanel.add(symptomsLabel);
                diseasePanel.add(Box.createRigidArea(new Dimension(0, 5)));
                diseasePanel.add(curesLabel);
                diseasePanel.add(Box.createRigidArea(new Dimension(0, 5)));
                diseasePanel.add(doctorsLabel);
                diseasePanel.add(Box.createRigidArea(new Dimension(0, 5)));
                diseasePanel.add(riskLevelLabel);
                diseasePanel.add(Box.createRigidArea(new Dimension(0, 10)));

                mainPanel.add(diseasePanel);
                mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            }
        }

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(new Color(44, 62, 80));


        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(44, 62, 80));

        JButton exitButton = new JButton("Exit");
        exitButton.setBackground(new Color(59, 89, 182));
        exitButton.setForeground(Color.WHITE);
        exitButton.setFocusPainted(false);
        exitButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        exitButton.setPreferredSize(new Dimension(100, 40));
        exitButton.addActionListener(e -> System.exit(0));

        buttonPanel.add(exitButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void writeUserInfoAndDiseasesToFile(String username, String email, String age, String phone, String gender, List<String> possibleDiseases, String[] selectedSymptomsArray) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("user_information.txt", true))) {
            writer.write("Username: " + username + ";");
            writer.write("Email: " + email + ";");
            writer.write("Age: " + age + ";");
            writer.write("Phone No.: " + phone + ";");
            writer.write("Gender: " + gender + ";");
            writer.write("Symptoms: " + String.join(", ", selectedSymptomsArray) + ";");

            writer.write("Predicted Diseases: ");
            for (int i = 0; i < possibleDiseases.size(); i++) {
                writer.write(possibleDiseases.get(i));
                if (i < possibleDiseases.size() - 1) {
                    writer.write(",");
                }
            }
            writer.write("\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
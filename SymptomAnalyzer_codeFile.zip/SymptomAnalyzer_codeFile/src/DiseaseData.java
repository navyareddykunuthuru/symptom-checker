import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

class Disease {
    private List<String> symptoms;
    private List<String> cures;
    private List<String> doctors;
    private String riskLevel;

    public Disease(List<String> symptoms, List<String> cures, List<String> doctors, String riskLevel) {
        this.symptoms = symptoms;
        this.cures = cures;
        this.doctors = doctors;
        this.riskLevel = riskLevel;
    }

    public List<String> getSymptoms() {
        return symptoms;
    }

    public List<String> getCures() {
        return cures;
    }

    public List<String> getDoctors() {
        return doctors;
    }

    public String getRiskLevel() {
        return riskLevel;
    }
}

class DiseaseData {
    private Map<String, Disease> diseaseMap;

    public DiseaseData() {
        diseaseMap = new HashMap<>();
        initializeDiseaseDataFromFile("D:\\symotom_checker\\dataset (1).txt");
    }

    private void initializeDiseaseDataFromFile(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 5) {
                    String diseaseName = parts[0].trim();
                    List<String> symptoms = Arrays.asList(parts[1].trim().split(","));
                    List<String> cures = Arrays.asList(parts[2].trim().split(","));
                    List<String> doctors = Arrays.asList(parts[3].trim().split(","));
                    String riskLevel = parts[4].trim();
                    diseaseMap.put(diseaseName, new Disease(symptoms, cures, doctors, riskLevel));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Disease getDiseaseByName(String diseaseName) {
        return diseaseMap.get(diseaseName);
    }

    public List<String> getDiseasesBySymptoms(String[] userSymptomsArray) {
        List<String> possibleDiseases = new ArrayList<>();
        List<String> userSymptomsList = Arrays.asList(userSymptomsArray);
        Map<String, Integer> diseaseMatchCount = new HashMap<>();

        for (Map.Entry<String, Disease> entry : diseaseMap.entrySet()) {
            String diseaseName = entry.getKey();
            Disease disease = entry.getValue();
            List<String> symptoms = disease.getSymptoms();
            int matchCount = 0;

            for (String userSymptom : userSymptomsList) {
                for (String diseaseSymptom : symptoms) {
                    if (diseaseSymptom.trim().equalsIgnoreCase(userSymptom.trim())) {
                        matchCount++;
                    }
                }
            }

            int userInputLength = userSymptomsArray.length;
            if (userInputLength == 1 && matchCount == 1) {
                diseaseMatchCount.put(diseaseName, matchCount);
            } else if (userInputLength == 2 && matchCount == 2) {
                diseaseMatchCount.put(diseaseName, matchCount);
            } else if (userInputLength == 3 && (matchCount == 3 || matchCount == 2)) {
                diseaseMatchCount.put(diseaseName, matchCount);
            } else if (userInputLength == 4 && (matchCount == 4 || matchCount == 3 || matchCount == 2)) {
                diseaseMatchCount.put(diseaseName, matchCount);
            } else if (userInputLength == 5 && (matchCount == 5 || matchCount == 4 || matchCount == 3)) {
                diseaseMatchCount.put(diseaseName, matchCount);
            } else if (userInputLength == 6 && (matchCount == 6 || matchCount == 5 || matchCount == 4)) {
                diseaseMatchCount.put(diseaseName, matchCount);
            }

        }

        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(diseaseMatchCount.entrySet());
        sortedEntries.sort(Map.Entry.<String, Integer>comparingByValue().reversed());

        for (Map.Entry<String, Integer> entry : sortedEntries) {
            possibleDiseases.add(entry.getKey());
        }
        return possibleDiseases;
    }
}

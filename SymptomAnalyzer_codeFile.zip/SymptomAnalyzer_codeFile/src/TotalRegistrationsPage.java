import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TotalRegistrationsPage extends JFrame {

    private static final Color BACKGROUND_COLOR = new Color(44, 62, 80);
    private static final Color CARD_COLOR = Color.WHITE;

    public TotalRegistrationsPage() {
        setTitle("Total User Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(BACKGROUND_COLOR);

        JLabel headerLabel = new JLabel("USER REGISTRATIONS", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        mainPanel.add(headerLabel);

        JPanel userInfoPanel = new JPanel();
        userInfoPanel.setLayout(new BoxLayout(userInfoPanel, BoxLayout.Y_AXIS));
        userInfoPanel.setBackground(BACKGROUND_COLOR);

        try (BufferedReader reader = new BufferedReader(new FileReader("user_information.txt"))) {
            String line;
            StringBuilder userData = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) {
                    addUserInfoToPanel(userInfoPanel, userData.toString());
                    userData.setLength(0);
                } else {
                    line = line.replace(";", "\n");
                    userData.append(line).append("\n");
                }
            }
            if (userData.length() > 0) {
                addUserInfoToPanel(userInfoPanel, userData.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(userInfoPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBackground(BACKGROUND_COLOR);
        scrollPane.getViewport().setBackground(BACKGROUND_COLOR);
        mainPanel.add(scrollPane);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 16));
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        backButton.addActionListener(e -> {
            dispose(); // Close current window
            new AdminCheckPage(); // Open AdminCheckPage
        });

        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        mainPanel.add(backButton);

        add(mainPanel);

        setVisible(true);
    }

    private void addUserInfoToPanel(JPanel userInfoPanel, String userData) {
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new BorderLayout());
        cardPanel.setBackground(CARD_COLOR);
        cardPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BACKGROUND_COLOR, 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        cardPanel.setMaximumSize(new Dimension(800, 900));

        JTextPane userInfoLabel = new JTextPane();
        userInfoLabel.setEditable(false);
        userInfoLabel.setBackground(CARD_COLOR);
        userInfoLabel.setForeground(Color.BLACK);
        userInfoLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        addStyledText(userInfoLabel, userData);

        cardPanel.add(userInfoLabel, BorderLayout.CENTER);
        userInfoPanel.add(cardPanel);
        userInfoPanel.add(Box.createRigidArea(new Dimension(0, 20)));
    }

    private void addStyledText(JTextPane textPane, String userData) {
        StyledDocument doc = textPane.getStyledDocument();

        Style regular = textPane.addStyle("Regular", null);
        StyleConstants.setFontFamily(regular, "Arial");
        StyleConstants.setFontSize(regular, 14);

        Style bold = textPane.addStyle("Bold", regular);
        StyleConstants.setBold(bold, true);

        String[] lines = userData.split("\n");

        for (String line : lines) {
            if (line.contains(":")) {
                String[] parts = line.split(":", 2);
                try {
                    if (parts[0].trim().equalsIgnoreCase("Username")) {
                        doc.insertString(doc.getLength(), "\n" + parts[0].toUpperCase() + ":", bold);
                        doc.insertString(doc.getLength(), parts[1].toUpperCase() + "\n", bold);
                    } else {
                        doc.insertString(doc.getLength(), parts[0] + ":", bold);
                        doc.insertString(doc.getLength(), parts[1] + "\n", regular);
                    }
                } catch (BadLocationException e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    doc.insertString(doc.getLength(), line + "\n", regular);
                } catch (BadLocationException e) {
                    e.printStackTrace();
                }
            }
        }
    }


}

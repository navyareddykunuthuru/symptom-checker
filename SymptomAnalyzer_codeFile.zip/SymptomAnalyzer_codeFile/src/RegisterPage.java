import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
public class RegisterPage extends JFrame {
    private HashMap<String, String> userCredentials;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheckBox;

    public RegisterPage() {
        setTitle("Registration Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500);
        setLocationRelativeTo(null);

        userCredentials = new HashMap<>();

        JLabel titleLabel = new JLabel("Register");
        titleLabel.setFont(new Font("Helvetica", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JTextField usernameField = createTextField(20);
        JTextField emailField = createTextField(20);
        JTextField ageField = createTextField(5);
        JTextField phoneField = createTextField(20);

        JComboBox<String> genderComboBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        passwordField = createPasswordField(10);

        showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.setForeground(Color.WHITE);
        showPasswordCheckBox.setBackground(new Color(44, 62, 80));
        showPasswordCheckBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (showPasswordCheckBox.isSelected()) {
                    passwordField.setEchoChar('\u0000');
                } else {
                    passwordField.setEchoChar('*');
                }
            }
        });

        JPanel contentPanel = createContentPanel(titleLabel, usernameField, emailField, ageField, phoneField, genderComboBox);

        JPanel buttonPanel = createButtonPanel();

        JButton registerButton = (JButton) buttonPanel.getComponent(0);
        registerButton.addActionListener(createRegisterButtonActionListener(usernameField, emailField, ageField, phoneField, genderComboBox));

        add(contentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JTextField createTextField(int columns) {
        JTextField textField = new JTextField(columns);
        textField.setForeground(Color.BLACK);
        textField.setEditable(true);
        return textField;
    }

    private JPasswordField createPasswordField(int columns) {
        JPasswordField passwordField = new JPasswordField(columns);
        passwordField.setForeground(Color.BLACK);
        passwordField.setEditable(true);
        return passwordField;
    }

    private JPanel createContentPanel(JLabel titleLabel, JTextField usernameField, JTextField emailField, JTextField ageField, JTextField phoneField, JComboBox<String> genderComboBox) {
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridBagLayout());
        contentPanel.setBackground(new Color(44, 62, 80));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.anchor = GridBagConstraints.WEST;

        contentPanel.add(titleLabel, gbc);
        addLabelAndFieldToPanel(contentPanel, "Username:", usernameField, gbc);
        addLabelAndFieldToPanel(contentPanel, "Email ID:", emailField, gbc);
        addLabelAndFieldToPanel(contentPanel, "Age:", ageField, gbc);
        addLabelAndFieldToPanel(contentPanel, "Phone Number:", phoneField, gbc);
        addLabelAndFieldToPanel(contentPanel, "Gender:", genderComboBox, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.WHITE);
        gbc.gridwidth = 1;
        contentPanel.add(passwordLabel, gbc);

        JPanel passwordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        passwordPanel.setBackground(new Color(44, 62, 80));
        passwordPanel.add(passwordField);
        passwordPanel.add(showPasswordCheckBox);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        contentPanel.add(passwordPanel, gbc);

        return contentPanel;
    }

    private void addLabelAndFieldToPanel(JPanel panel, String labelText, JComponent field, GridBagConstraints gbc) {
        JLabel label = new JLabel(labelText);
        label.setForeground(Color.WHITE);
        panel.add(label, gbc);
        panel.add(field, gbc);
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(44, 62, 80));

        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back");

        registerButton.setForeground(Color.BLACK);
        backButton.setForeground(Color.BLACK);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new WelcomePage();
                dispose();
            }
        });

        buttonPanel.add(registerButton);
        buttonPanel.add(backButton);

        return buttonPanel;
    }
    private void writeUserInfoToFile(String username, String email, String age, String phone, String gender, List<String> predictedDiseases) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("user_info.txt"))) {
            writer.write("Username: " + username + "\n");
            writer.write("Email: " + email + "\n");
            writer.write("Age: " + age + "\n");
            writer.write("Phone: " + phone + "\n");
            writer.write("Gender: " + gender + "\n");
            writer.write("Predicted Diseases:\n");
            for (String disease : predictedDiseases) {
                writer.write(disease + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ActionListener createRegisterButtonActionListener(JTextField usernameField, JTextField emailField, JTextField ageField, JTextField phoneField, JComboBox<String> genderComboBox) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText().trim();
                String email = emailField.getText().trim();
                String ageText = ageField.getText();
                String phoneText = phoneField.getText();
                String password = new String(passwordField.getPassword());

                if (!isValidRegistrationData(username, email, ageText, phoneText, password)) {
                    return;
                }

                userCredentials.put(username, password);

                String userDetails = "Username: " + username + "\n" +
                        "Email: " + email + "\n" +
                        "Age: " + ageText + "\n" +
                        "Phone Number: " + phoneText + "\n" +
                        "Gender: " + genderComboBox.getSelectedItem() + "\n";
                JOptionPane.showMessageDialog(RegisterPage.this, userDetails, "Registration Details", JOptionPane.INFORMATION_MESSAGE);
                UserData userData = UserData.getInstance();
                userData.setUsername(username);
                userData.setEmail(email);
                userData.setAge(ageText);
                userData.setPhone(phoneText);
                userData.setGender((String) genderComboBox.getSelectedItem());

                new LoginPage(userCredentials);
                dispose();
            }

            private boolean isValidRegistrationData(String username, String email, String ageText, String phoneText, String password) {
                if (username.length() < 3 || !username.matches("[a-zA-Z]+")) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "Please enter a valid username.", "Invalid Username", JOptionPane.ERROR_MESSAGE);
                    usernameField.requestFocus();
                    return false;
                }

                if (!email.matches("^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "Please enter a valid email address.", "Invalid Email", JOptionPane.ERROR_MESSAGE);
                    emailField.requestFocus();
                    return false;
                }

                if (!ageText.matches("\\d{1,2}")) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "Please enter a valid age.", "Invalid Age", JOptionPane.ERROR_MESSAGE);
                    ageField.requestFocus();
                    return false;
                }

                if (!phoneText.matches("[6789]\\d{9}")) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "Please enter a valid phone number.", "Invalid Phone Number", JOptionPane.ERROR_MESSAGE);
                    phoneField.requestFocus();
                    return false;
                }

                if (password.isEmpty()) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "Password is required.", "Invalid Password", JOptionPane.ERROR_MESSAGE);
                    passwordField.requestFocus();
                    return false;
                }

                return true;
            }
        };
    }
}
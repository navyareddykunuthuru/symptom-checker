import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.HashSet;
import java.util.Set;

public class AdmininputPage extends JFrame {

    public AdmininputPage() {
        setTitle("Admin Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500);
        setLocationRelativeTo(null);

        JLabel titleLabel = new JLabel("Admin Entry");
        titleLabel.setFont(new Font("Helvetica", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JTextField symptomsField = createTextField(20);
        JTextField diseaseField = createTextField(20);
        JTextField riskLevelField = createTextField(20);
        JTextField cureField = createTextField(20);
        JTextField doctorField = createTextField(20);

        JPanel contentPanel = createContentPanel(titleLabel, symptomsField, diseaseField, riskLevelField, cureField, doctorField);

        JPanel buttonPanel = createButtonPanel(symptomsField, diseaseField, riskLevelField, cureField, doctorField);

        add(contentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JTextField createTextField(int columns) {
        JTextField textField = new JTextField(columns);
        textField.setForeground(Color.BLACK);
        textField.setEditable(true);
        return textField;
    }

    private JPanel createContentPanel(JLabel titleLabel, JTextField symptomsField, JTextField diseaseField, JTextField riskLevelField, JTextField cureField, JTextField doctorField) {
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridBagLayout());
        contentPanel.setBackground(new Color(44, 62, 80));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.anchor = GridBagConstraints.WEST;

        contentPanel.add(titleLabel, gbc);
        addLabelAndFieldToPanel(contentPanel, "Symptoms:", symptomsField, gbc);
        addLabelAndFieldToPanel(contentPanel, "Disease:", diseaseField, gbc);
        addLabelAndFieldToPanel(contentPanel, "Risk Level:", riskLevelField, gbc);
        addLabelAndFieldToPanel(contentPanel, "Cure:", cureField, gbc);
        addLabelAndFieldToPanel(contentPanel, "Doctor Recommendation:", doctorField, gbc);

        return contentPanel;
    }

    private void addLabelAndFieldToPanel(JPanel panel, String labelText, JComponent field, GridBagConstraints gbc) {
        JLabel label = new JLabel(labelText);
        label.setForeground(Color.WHITE);
        panel.add(label, gbc);
        panel.add(field, gbc);
    }

    private JPanel createButtonPanel(JTextField symptomsField, JTextField diseaseField, JTextField riskLevelField, JTextField cureField, JTextField doctorField) {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(44, 62, 80));

        JButton submitButton = new JButton("Submit");
        JButton backButton = new JButton("Back");

        submitButton.setForeground(Color.BLACK);
        backButton.setForeground(Color.BLACK);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AdminCheckPage();
                dispose();
            }
        });

        submitButton.addActionListener(createSubmitButtonActionListener(symptomsField, diseaseField, riskLevelField, cureField, doctorField));

        buttonPanel.add(submitButton);
        buttonPanel.add(backButton);

        return buttonPanel;
    }

    private ActionListener createSubmitButtonActionListener(JTextField symptomsField, JTextField diseaseField, JTextField riskLevelField, JTextField cureField, JTextField doctorField) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String symptoms = symptomsField.getText().trim();
                String disease = diseaseField.getText().trim();
                String riskLevel = riskLevelField.getText().trim();
                String cure = cureField.getText().trim();
                String doctor = doctorField.getText().trim();

                if (!isValidAdminData(symptoms, disease, riskLevel, cure, doctor)) {
                    return;
                }

                appendToDataset(symptoms, disease, riskLevel, cure, doctor);

                JOptionPane.showMessageDialog(AdmininputPage.this, "Data successfully submitted.", "Submission Success", JOptionPane.INFORMATION_MESSAGE);

                symptomsField.setText("");
                diseaseField.setText("");
                riskLevelField.setText("");
                cureField.setText("");
                doctorField.setText("");
            }

            private boolean isValidAdminData(String symptoms, String disease, String riskLevel, String cure, String doctor) {
                if (symptoms.isEmpty() || symptoms.length() < 3) {
                    JOptionPane.showMessageDialog(AdmininputPage.this, "Please enter valid symptoms (minimum 3 characters).", "Invalid Symptoms", JOptionPane.ERROR_MESSAGE);
                    symptomsField.requestFocus();
                    return false;
                }

                if (disease.isEmpty() || disease.length() < 3) {
                    JOptionPane.showMessageDialog(AdmininputPage.this, "Please enter a valid disease name (minimum 3 characters).", "Invalid Disease", JOptionPane.ERROR_MESSAGE);
                    diseaseField.requestFocus();
                    return false;
                }

                if (riskLevel.isEmpty() || !riskLevel.matches("Low|Medium|High|low|medium|high")) {
                    JOptionPane.showMessageDialog(AdmininputPage.this, "Please enter a valid risk level (Low, Medium, or High).", "Invalid Risk Level", JOptionPane.ERROR_MESSAGE);
                    riskLevelField.requestFocus();
                    return false;
                }

                if (cure.isEmpty() || cure.length() < 3) {
                    JOptionPane.showMessageDialog(AdmininputPage.this, "Please enter a valid cure (minimum 3 characters).", "Invalid Cure", JOptionPane.ERROR_MESSAGE);
                    cureField.requestFocus();
                    return false;
                }

                if (doctor.isEmpty() || doctor.length() < 3) {
                    JOptionPane.showMessageDialog(AdmininputPage.this, "Please enter a valid doctor recommendation (minimum 3 characters).", "Invalid Doctor Recommendation", JOptionPane.ERROR_MESSAGE);
                    doctorField.requestFocus();
                    return false;
                }

                return true;
            }

            private void appendToDataset(String symptoms, String disease, String riskLevel, String cure, String doctor) {
                String filename = "dataset (1).txt";
                Set<String> symptomSet = new HashSet<>();
                try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.split(";");
                        if (parts.length > 2) {
                            symptomSet.add(parts[2]);
                        }
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(AdmininputPage.this, "Error reading file.", "File Error", JOptionPane.ERROR_MESSAGE);
                }

                symptomSet.add(symptoms);

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
                    String dataLine = "\n" + disease + ";" + symptoms + ";" + cure + ";" + doctor + ";" + riskLevel + "\n";
                    writer.write(dataLine);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(AdmininputPage.this, "Error writing to file.", "File Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
    }

}
